function setup() {
  createCanvas(500, 300);
}

function draw() {
  background(135, 206, 235); // sky
  
  // sun
  fill(255, 204, 0);
  noStroke();
  ellipse(80, 70, 70, 70);

  // sun rays
  stroke(255, 204, 0);
  strokeWeight(3);

  line(80, 20, 80, 0);
  line(80, 120, 80, 140);
  line(30, 70, 10, 70);
  line(130, 70, 150, 70);

  line(45, 35, 30, 20);
  line(115, 35, 130, 20);
  line(45, 105, 30, 120);
  line(115, 105, 130, 120);

  noStroke();

  // ground
  fill(90);
  rect(0, 200, width, 100);

  // car body (blue)
  fill(0, 102, 204);
  rect(150, 150, 200, 50, 10); // rounded edges
  
  // car top
  rect(200, 120, 100, 40, 10);

  // windows
  fill(180, 220, 255);
  rect(210, 125, 35, 30, 5);
  rect(255, 125, 35, 30, 5);

  // wheels
  fill(30);
  ellipse(190, 210, 45, 45);
  ellipse(310, 210, 45, 45);

  // wheel rims
  fill(200);
  ellipse(190, 210, 20, 20);
  ellipse(310, 210, 20, 20);

  // headlights
  fill(255, 255, 0);
  ellipse(350, 170, 10, 10);

  // tail light
  fill(255, 0, 0);
  ellipse(150, 170, 10, 10);
}