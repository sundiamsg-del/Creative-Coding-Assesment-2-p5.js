let table;

function preload() {
  // Load the CSV file before the program starts
  table = loadTable('data2.csv', 'csv', 'header');
}

function setup() {
  createCanvas(500, 350);
}

function draw() {
  background(255);

  let barW = 70;   // width of each bar
  let maxVal = 650;     // highest value for scaling

  // Title text
  fill(0);
  textAlign(CENTER);
  textSize(14);
  text("Global Sports Popularity (Estimated Players in Millions)", width / 2, 30);

  // Loop through each row in the CSV file
  for (let i = 0; i < table.getRowCount(); i++) {

    // Get data from CSV columns
    let sport = table.getString(i, "Sport");
    let players = table.getNum(i, "Players");

    // Position of each bar
    let x = 40 + i * (barW + 15);

    // Convert data value into bar height
    let h = map(players, 0, maxVal, 0, 260);

    // Draw bar
    fill(0, 150, 255);
    rect(x, height - h - 40, barW, h);

    // Draw sport label under bar
    fill(0);
    textSize(11);
    textAlign(CENTER);
    text(sport, x + barW / 2, height - 20);
  }
}