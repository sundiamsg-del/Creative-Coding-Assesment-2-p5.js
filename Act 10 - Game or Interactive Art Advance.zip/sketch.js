// ===== GAME VARIABLES =====
let playerX;          // X position of player (basket)
let playerW = 80;     // width of basket

let objX, objY;       // falling object position
let objSize = 20;     // size of object

let speed = 4;        // falling speed (gets faster)
let score = 0;        // player score

let gameState = "start"; // game states: start, playing, gameover

// ===== SETUP FUNCTION (runs once) =====
function setup() {
  createCanvas(500, 400);
  playerX = width / 2; // start player in center
}

// ===== MAIN GAME LOOP =====
function draw() {
  background(20);

  // Show start screen
  if (gameState === "start") {
    drawStartScreen();
    return;
  }

  // Show game over screen
  if (gameState === "gameover") {
    drawGameOverScreen();
    return;
  }

  // Play the game
  drawGame();
}

// ===== GAMEPLAY =====
function drawGame() {
  // 🎮 Draw player (basket)
  fill(0, 150, 255);
  rectMode(CENTER);
  rect(playerX, height - 20, playerW, 20);

  // 🎯 Draw falling object
  fill(255, 200, 0);
  circle(objX, objY, objSize);

  // Move object downward
  objY += speed;

  // 📊 Show score
  fill(255);
  textSize(20);
  textAlign(LEFT);
  text("Score: " + score, 20, 30);

  // ❌ If object reaches bottom → GAME OVER
  if (objY > height) {
    gameState = "gameover";
  }

  // ✅ Check if player catches object
  if (
    objY + objSize / 2 > height - 30 && // near basket
    objX > playerX - playerW / 2 &&     // inside left side
    objX < playerX + playerW / 2        // inside right side
  ) {
    score++;            // increase score
    newObject();        // spawn new object
    increaseDifficulty();// make game harder
  }
}

// ===== START SCREEN =====
function drawStartScreen() {
  fill(255);
  textAlign(CENTER);
  textSize(30);
  text("Catch the Falling Objects", width / 2, height / 2 - 60);

  drawButton(width / 2, height / 2 + 20, "PLAY");
}

// ===== GAME OVER SCREEN =====
function drawGameOverScreen() {
  fill(255);
  textAlign(CENTER);
  textSize(30);
  text("GAME OVER", width / 2, height / 2 - 60);

  textSize(20);
  text("Score: " + score, width / 2, height / 2 - 20);

  drawButton(width / 2, height / 2 + 40, "RESTART");
}

// ===== BUTTON DRAW FUNCTION =====
function drawButton(x, y, label) {
  fill(0, 180, 255);
  rectMode(CENTER);
  rect(x, y, 140, 50, 10);

  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text(label, x, y);
}

// ===== CLICK TO START / RESTART =====
function mousePressed() {
  if (gameState === "start") {
    startGame();
  } else if (gameState === "gameover") {
    startGame();
  }
}

// ===== START / RESET GAME =====
function startGame() {
  score = 0;       // reset score
  speed = 4;       // reset speed
  objSize = 20;    // reset size
  playerW = 80;    // reset basket size

  playerX = width / 2; // reset position

  newObject();     // spawn first object

  gameState = "playing"; // start game
}

// ===== MOVE PLAYER WITH MOUSE =====
function mouseMoved() {
  if (gameState === "playing") {
    playerX = mouseX;
  }
}

// ===== SPAWN NEW OBJECT =====
function newObject() {
  objX = random(20, width - 20); // random X position
  objY = 0;                       // start at top
}

// ===== INCREASE DIFFICULTY =====
function increaseDifficulty() {
  speed += 0.3;     // make objects fall faster
  objSize -= 0.2;   // make object smaller

  // limit values so game stays playable
  objSize = max(objSize, 10);
  speed = min(speed, 12);
}