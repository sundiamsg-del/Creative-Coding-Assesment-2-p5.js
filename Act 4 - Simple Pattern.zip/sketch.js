function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);

  for (let x = 0; x < width; x += 40) {
    for (let y = 0; y < height; y += 40) {
      fill(random(100), random(35), random(60));
      rect(x, y, 30, 30);
    }
  }
}