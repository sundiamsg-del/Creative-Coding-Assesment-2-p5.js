function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textFont("Arial Black");
}

function draw() {
  background(20);

  let t = "Carpe Diem";

  translate(width / 2, height / 2);

  // shadow layer (gives depth)
  fill(0);
  textSize(64);
  text(t, 5, 5);

  // colored layer behind
  fill(0, 150, 255);
  textSize(64);
  text(t, 0, 0);

  // top layer (main text)
  fill(255);
  textSize(60);
  text(t, 0, 0);
}