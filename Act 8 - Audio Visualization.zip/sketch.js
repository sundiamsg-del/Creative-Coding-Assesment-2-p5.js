let mic;

function setup() {
  createCanvas(500, 400);
  mic = new p5.AudioIn();
  mic.start();
}

function draw() {
  background(0);

  let volume = mic.getLevel();

  // CENTER PULSE (different style: rectangle instead of circle)
  let pulse = map(volume, 0, 0.3, 30, 180);

  noStroke();
  fill(0, 180, 255);
  rectMode(CENTER);
  rect(width / 2, height / 2, pulse, pulse);

  // soft glow layer
  fill(0, 180, 255, 60);
  rect(width / 2, height / 2, pulse + 40, pulse + 40);

  // SIMPLE RING (not rotating, just expanding)
  noFill();
  stroke(150, 220, 255);
  ellipse(width / 2, height / 2, pulse + 80);

  // BOTTOM SOUND BARS
  let bars = 8;
  let barWidth = width / bars;

  for (let i = 0; i < bars; i++) {
    let barHeight = map(volume, 0, 0.3, 5, 150);

    fill(80 + i * 20, 150, 255);
    noStroke();

    rect(
      i * barWidth + barWidth / 2,
      height - barHeight / 2,
      barWidth - 10,
      barHeight
    );
  }

  // TEXT
  fill(255);
  noStroke();
  textAlign(CENTER);
  textSize(14);
  text("Microphone Visual Art", width / 2, 30);
}