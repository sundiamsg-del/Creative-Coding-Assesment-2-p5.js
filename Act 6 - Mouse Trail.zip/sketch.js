function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  fill(random (50), random(255), random(255), 200);
  noStroke();
  rect(mouseX, mouseY, 30, 30);
}