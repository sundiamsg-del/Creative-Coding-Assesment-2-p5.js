function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20); // dark space background
  
  //Alien head
fill(0, 100, 0); // green color
noStroke();
ellipse(200, 180, 180, 200);
ellipse(200, 270, 110, 130);
  
  //eyes
fill(0); // black eyes
ellipse(160, 170, 40, 80);
ellipse(240, 170, 40, 80);
ellipse(200, 170, 40, 80);
  
  //Eye shine
fill(	139, 0, 0);
ellipse(150, 150, 10, 20);
ellipse(230, 150, 10, 20);
ellipse(199, 150, 10, 20);
  
  //Alien mouth
fill(0);
arc(200, 230, 60, 40, 0, PI);
ellipse(170, 290, 15, 60);
ellipse(200, 290, 15, 60);
ellipse(230, 290, 15, 60);
  
  //atena
stroke(0, 100, 0);
strokeWeight(4);
line(170, 80, 150, 40);
line(230, 80, 250, 40);
  
  // Antenna circle
noStroke();
fill(255, 0, 200);
ellipse(150, 40, 15, 15);
ellipse(250, 40, 15, 15);
  
}