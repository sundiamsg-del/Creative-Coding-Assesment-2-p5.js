let img;
let maskedImg;

function preload() {
  img = loadImage("pika.png");
}

function setup() {
  createCanvas(900, 450);
  noLoop();

  
  let maskGraphics = createGraphics(400, 400);
  maskGraphics.background(0);
  maskGraphics.fill(255);
  maskGraphics.noStroke();
  maskGraphics.ellipse(200, 200, 300, 300);

  maskedImg = img.get();
  maskedImg.resize(400, 400);
  maskedImg.mask(maskGraphics);
}

function draw() {
  background(240);

  
  push();
  translate(50, 25);

  drawingContext.save();
  drawingContext.beginPath();
  drawingContext.arc(200, 200, 150, 0, TWO_PI);
  drawingContext.clip();

  image(img, 0, 0, 400, 400);

  drawingContext.restore();
  pop();

 
  image(maskedImg, 450, 25);


  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  text("CLIP", 250, 400);
  text("MASK", 650, 400);

 
  watercolorEffect();
}

function watercolorEffect() {
  noStroke();
  for (let i = 0; i < 200; i++) {
    fill(92, 0, 89, 50);
    ellipse(
      random(width),
      random(height),
      random(20, 80)
    );
  }
}