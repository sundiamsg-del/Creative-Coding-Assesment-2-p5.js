let r = 255;
let g = 255;
let b = 255;

function setup() {
  createCanvas(500, 400);
  background(0);
}

function draw() {
  // slowly clears old circles
  background(0, 20);

  fill(r, g, b);
  noStroke();

  // circles follow mouse
  circle(mouseX, mouseY, 100);
}

// click to change color
function mousePressed() {
  r = random(255);
  g = random(255);
  b = random(255);
}